//Difficulty = amount of missing numbers
export const Difficulty: { [key: string]: number } = {
  supereasy: 1,
  easy: 35,
  medium: 45,
  hard: 55,
  expert: 60,
};
