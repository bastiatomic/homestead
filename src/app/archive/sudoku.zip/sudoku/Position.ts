export interface Position {
    value : number;
    isFixed? : boolean;

}