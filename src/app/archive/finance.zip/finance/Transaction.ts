export interface Transaction {
    date: any;
    name: String;
    value: String | number | null;
    counterpart: String;
    category: String;
    account?: String;
  }